package com.example.katyao;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        TextView mainTextView = findViewById(R.id.main_textview);
        mainTextView.setText("Set in Java!");
        Button helloButton = findViewById(R.id.hello_button);
        EditText nameInput = findViewById(R.id.name_input);

        helloButton.setOnClickListener(v -> {
            String name = nameInput.getText().toString().trim();
            if (!name.isEmpty()) {
                mainTextView.setText("Привет, " + name + " ИСп23-1");
            } else {
                mainTextView.setText("Введи своё имя");
            }
        });
    }}